const express = require('express');
const jwt = require('jsonwebtoken');

const indexController = require("../controllers/indexController");
const userController = require("../controllers/userController");
const adminController = require("../controllers/adminController");

const jwt_secret = 'abcde#123';
const router = express.Router();

// ===========================================
// ===========================================

function Authorize_librarian(req, res, next) {
    const token = req.cookies.librarianToken;

    if (!token) {
        return res.redirect('/login');
    }

    try {
        req.indexroute = jwt.verify(token, jwt_secret);
        next();

    } catch (e) {
        res.redirect('/login');
    }
}

function Authorize_librarian_HTTP(req, res, next) {
    var token = req.cookies.librarianToken;
    if (!token) {
        res.json({ error: true, message: "ERROR" });
    } else {
        try {
            req.indexroute = jwt.verify(token, jwt_secret);
            next();

        } catch (e) {
            res.json({ error: true, message: "ERROR" });
        }
    }
}

// ===========================================
// ===========================================

// ==== Login Pages - Admin / Librarian / Student ====
router.get('/', indexController.renderIndexPage);

// ==== Librarian Login ====
router.get('/login', indexController.renderlibloginPage);
router.post('/login', indexController.logindata);

// ==== Librarian Dashboard ====
router.get('/librariandashboard', Authorize_librarian, indexController.renderlibrariandashboardPage);

// ==== Manage Books ====
router.get('/addbook', Authorize_librarian, indexController.renderaddbookPage);
router.get('/fetchcategory', indexController.fetchcategories);
router.post('/addbookdata', indexController.addbookdata);
router.get('/viewsubcategory', indexController.viewsubcategory);
router.delete("/deletesubcategory/:bookId", indexController.deletesubcategory);

// ==== Issue Books ====
router.get('/issuebooks', Authorize_librarian, indexController.renderissuebooksPage);
router.post('/issuebooks', indexController.issueBookHandler);

// ==== Return Book ====
router.post('/returnbook', indexController.returnBookHandler);

// ==== Fine Payment ====
router.post('/submitFinePayment', indexController.submitFinePayment);

// ==== Fetch Issued Books ====
router.get('/issuedata', indexController.issuedata);

// ==== Fetch Book by Category of Book ====
router.get('/fetchbook/:categoryId', indexController.fetchbook);

// ==== Fetch Student by Branch Id ====
router.get('/fetchstudent/:branchId', indexController.fetchstudent);

router.put("/return/:id", indexController.return);
router.put("/changestatus/:id", indexController.changestatus);
router.put("/changestatus2/:bookId", indexController.changestatus2);

router.get('/changepass', indexController.renderchangepassPage);
router.put('/updatepass', indexController.updatepass);

router.get('/logoutlib', Authorize_librarian, indexController.logoutlib)

module.exports = router;