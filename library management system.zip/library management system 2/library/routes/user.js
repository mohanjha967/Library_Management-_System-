const express = require('express');
const jwt = require('jsonwebtoken');

const userController = require('../controllers/userController');

var router = express.Router();
const jwt_secret = 'abcd#1234';

// ===========================================
// ===========================================

function Authorize_user(req, res, next) {
    const token = req.cookies.userToken;

    if (!token) {
        return res.redirect('/user/login');
    }

    try {
        req.user = jwt.verify(token, jwt_secret);
        next();
    } catch (e) {
        res.redirect('/user/login');
    }
}

function Authorize_user_HTTP(req, res, next) {
    const token = req.cookies.userToken;

    if (!token) {
        return res.json({ error: true, message: "ERROR" });
    }

    try {
        req.user = jwt.verify(token, jwt_secret);
        next();
    } catch (e) {
        res.json({ error: true, message: "ERROR" });
    }
}

// ===========================================
// ===========================================

// router.get('/usersignup', userController.renderusersignupPage);
// router.post('/signupuser', userController.signupuser);

// ==== Student Login ====
router.get('/login', userController.renderloginPage);
router.post('/login', userController.loginUser);

// ==== Student Dashboard ====
router.get('/dashboard', Authorize_user, userController.renderdashboardPage);
router.get('/dashboard-counts', Authorize_user, userController.userDashboardCounts);

// ==== Fetch Issued Books ====
router.get('/userbook', Authorize_user_HTTP, userController.userbook);

router.get('/userbooks', userController.renderuserbooks);
router.get('/userbookdata', Authorize_user, userController.userbookdata);

router.get('/available', userController.renderavailable);
router.get('/viewallbooks/:categoryId', userController.viewallbooks);
router.get('/viewbooks', userController.viewbooks);

router.get('/changepassword', userController.renderchangepasswordPage);
router.put('/updatepassword', userController.updatepassword);

router.get('/logout', Authorize_user, userController.logout)

module.exports = router;