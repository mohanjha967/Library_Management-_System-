var Sequelize = require("sequelize");

var dbName = 'node_library_management';
var dbUser = 'root';
var dbPassword = 'itm@12';

var sequelize = new Sequelize(dbName, dbUser, dbPassword, {
   host: 'localhost',
   port: 3306,
   dialect: 'mysql',
   pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000
   }
});

var db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

/* =======================
   MODELS
======================= */

db.admin = require('./models/Admin')(sequelize, Sequelize);
db.user = require('./models/userpg')(sequelize, Sequelize);
db.librarian = require('./models/librarianpg')(sequelize, Sequelize);
db.addcategory = require('./models/addcategory')(sequelize, Sequelize);
db.book = require('./models/book')(sequelize, Sequelize);

db.degree = require('./models/degreetype')(sequelize, Sequelize);
db.course = require('./models/course')(sequelize, Sequelize);
db.branch = require('./models/branch')(sequelize, Sequelize);

db.issueBook = require('./models/issuebooks')(sequelize, Sequelize);

/* =======================
   RELATIONSHIPS
======================= */

/* Category → Books */
db.addcategory.hasMany(db.book, { foreignKey: 'categoryId' });
db.book.belongsTo(db.addcategory, { foreignKey: 'categoryId' });

/* Degree → Course */
db.degree.hasMany(db.course, { foreignKey: 'degreeId' });
db.course.belongsTo(db.degree, { foreignKey: 'degreeId' });

/* Course → Branch */
db.course.hasMany(db.branch, { foreignKey: 'courseId' });
db.branch.belongsTo(db.course, { foreignKey: 'courseId' });

/* Branch → Users (Students) */
db.branch.hasMany(db.user, { foreignKey: 'branchId' });
db.user.belongsTo(db.branch, { foreignKey: 'branchId' });

/* =======================
   ISSUE BOOK RELATIONS
======================= */

/* User → IssueBooks */
db.user.hasMany(db.issueBook, { foreignKey: 'userId' });
db.issueBook.belongsTo(db.user, { foreignKey: 'userId' });

/* Book → IssueBooks */
db.book.hasMany(db.issueBook, { foreignKey: 'bookId' });
db.issueBook.belongsTo(db.book, { foreignKey: 'bookId' });

/* Admin → IssueBooks (Audit) */
// db.admin.hasMany(db.issueBook, { foreignKey: 'issuedBy', as: 'IssuedBooks' });
// db.issueBook.belongsTo(db.admin, { foreignKey: 'issuedBy', as: 'IssuedByAdmin' });

// db.admin.hasMany(db.issueBook, { foreignKey: 'returnedBy', as: 'ReturnedBooks' });
// db.issueBook.belongsTo(db.admin, { foreignKey: 'returnedBy', as: 'ReturnedByAdmin' });

module.exports = db;
