const jwt = require('jsonwebtoken');

const db = require('../db.config');

const book = db.book;
const UserModal = db.user;
const addcategory = db.addcategory;
const issueBook = db.issueBook;

const Sequelize = db.Sequelize;

const jwt_secret = 'abcd#1234';


// ===========================================

const userController = {};

userController.renderloginPage = (req, res) => {
    res.render('user/usersignin');
}

userController.loginUser = async (req, res) => {
    try {
        var { email, password } = req.body;
        var result = await UserModal.findAll({ where: { email: email, password: password } });
        if (result.length > 0) {
            //var result=await UserModal.findAll({where:{email:email ,password:password}});
            var status = result[0].status;
            if (status == 'Active') {
                var payload = {
                    id: result[0].id,
                    name: result[0].name,
                    email: result[0].email
                };
                var token = jwt.sign(payload, jwt_secret, { expiresIn: '1h' });
                res.cookie('userToken', token);

                res.json({ error: false, message: "login successful" });

            } else {
                res.json({ error: true, message: "User Blocked" });
            }
        }
        else {
            res.json({ error: true, message: "Invalid Credentials" });
        }
    }
    catch (e) {
        res.json({ error: true, message: e.message });
    }
}

userController.renderdashboardPage = (req, res) => {
    res.render('user/dashboard');
}

userController.userDashboardCounts = async (req, res) => {
    try {

        const { id } = req.user;

        const counts = await issueBook.findAll({
            attributes: [
                [
                    Sequelize.fn(
                        "SUM",
                        Sequelize.literal("CASE WHEN status = 'Issued' THEN 1 ELSE 0 END")
                    ),
                    "issuedBooks"
                ],
                [
                    Sequelize.fn(
                        "SUM",
                        Sequelize.literal("CASE WHEN status = 'Overdue' THEN 1 ELSE 0 END")
                    ),
                    "overdueBooks"
                ],
                [
                    Sequelize.fn(
                        "SUM",
                        Sequelize.literal("CASE WHEN status = 'Returned' THEN 1 ELSE 0 END")
                    ),
                    "returnedBooks"
                ]
            ],
            where: {
                userId: id
            },
            raw: true
        });

        return res.json({
            error: false,
            message: "Dashboard counts fetched successfully",
            data: counts[0]
        });

    } catch (e) {

        return res.json({
            error: true,
            message: e.message || "Internal Server Error",
            data: {}
        });

    }
};

userController.renderuserbooks = (req, res) => {
    res.render('user/userbooks');
}


userController.userbookdata = async (req, res) => {
    try {
        var id = req.user.id;
        var records = await issueBook.findAll(
            {
                where: { userId: id },
                include: [
                    {
                        model: book,
                        attributes: ['id', 'title']
                    },
                    {
                        model: UserModal,
                        attributes: ['id', 'name']
                    }
                ],
                order: [['id', 'DESC']]
            }
        );

        res.json({ error: false, message: 'Data Fetched ', records: records });
    } catch (e) {
        res.json({ error: true, message: e.message, records: [] });
    }
}

userController.userbook = async (req, res) => {
    try {
        const { id } = req.user;

        const records = await issueBook.findAll({
            where: {
                userId: id,
                status: ['Issued', 'Overdue']   // student ko overdue books bhi dikhe
            },
            attributes: [
                'id',
                [Sequelize.fn('DATE_FORMAT', Sequelize.col('issuedAt'), '%d-%m-%Y'), 'issuedAt'],
                [Sequelize.fn('DATE_FORMAT', Sequelize.col('dueDate'), '%d-%m-%Y'), 'dueDate'],
                'fineAmount',
                'status'
            ],
            include: [
                {
                    model: book,
                    attributes: ['id', 'title']
                },
            ],
            order: [['issuedAt', 'DESC']]
        });

        return res.json({
            error: false,
            message: "Issued books fetched successfully",
            records: records
        });

    } catch (e) {

        return res.json({
            error: true,
            message: e.message || "Internal Server Error",
            records: []
        });

    }
}


userController.renderavailable = (req, res) => {
    res.render('user/available');
}
userController.viewallbooks = async (req, res) => {
    try {
        const { categoryId } = req.params;

        const records = await book.findAll(
            {
                where: { 
                    status: 'Available',
                    categoryId: categoryId
                 },
                include: [
                    {
                        model: addcategory,
                        attributes: ['name', 'id']
                    }
                ]

            });

        res.json({ message: 'Data Fetched ', records: records });
    } catch (e) {
        res.json({ message: e.message, records: [] });
    }
}

userController.viewbooks = async (req, res) => {
    try {

        // console.log(categoryId)
        var records = await book.findAll(



        );
        // console.log(records);
        res.json({ message: 'Data Fetched ', records: records });

    } catch (e) {
        res.json({ message: e.message, records: [] });

    }
}


userController.renderchangepasswordPage = (req, res) => {
    res.render('user/changepassword');
}


userController.updatepassword = async (req, res) => {
    try {

        var { email, password, newpassword } = req.body;
        var record = await UserModal.findAll({ where: { email: email, password: password } });
        if (record.length > 0) {

            await UserModal.update({ password: newpassword }, { where: { email: email } });
            res.json({ error: false, message: 'Password Changed Successfully' });

        }
        else {
            res.json({ error: true, message: 'Password or Email do not match' });
        }
    }
    catch (e) {
        res.json({ error: true, message: e.message });
    }
}

userController.logout = (req, res) => {
    //console.log("hello ")
    res.clearCookie('userToken');
    //  res.json({error: false, message: "login successful"});
    res.redirect('/');
}

module.exports = userController;