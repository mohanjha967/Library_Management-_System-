const jwt = require("jsonwebtoken");



var db = require('../db.config');

const sequelize = db.sequelize;
const Sequelize = db.Sequelize;

var book = db.book;
var UserModal = db.user;
var librarian = db.librarian;
var issueBook = db.issueBook;
var addcategory = db.addcategory;

var jwt_secret = 'abcde#123';



var indexController = {};

indexController.renderIndexPage = async (req, res) => {
   res.render('index');
}



indexController.createNewlibrarian = async (req, res) => {
   try {
      await librarian.create(req.body);
      res.json({ error: false, message: "Data Added Successfully" });

   } catch (e) {
      res.json({ error: true, message: e.message });
   }
}

indexController.renderlibloginPage = (req, res) => {
   res.render('librarian/signin');
}

indexController.logindata = async (req, res) => {
   try {
      var { email, password } = req.body;
      var records = await librarian.findAll({ where: { email: email, password: password } });
      // console.log(records);
      // console.log(records.length);
      if (records.length > 0) {
         var payload = {
            id: records[0].id,
            name: records[0].name,
            email: records[0].email
         };
         var token = jwt.sign(payload, jwt_secret, { expiresIn: '1h' });
         res.cookie('librarianToken', token);
         res.json({ message: 'Data Fetched ', error: false });
      }
      else {
         res.json({ error: true, message: 'Data Not Matched' });
      }

   } catch (e) {
      res.json({ message: e.message, error: true });

   }
}
indexController.renderlibrariandashboardPage = (req, res) => {
   res.render('librarian/librariandashboard');
}

indexController.renderaddbookPage = (req, res) => {
   res.render('librarian/addbook');
}

indexController.fetchcategories = async (req, res) => {
   try {
      var records = await addcategory.findAll();
      res.json({ message: 'Data Fetched ', records: records });
   } catch (e) {
      res.json({ message: e.message, records: [] });

   }
}

indexController.addbookdata = async (req, res) => {
   try {
      if (!req.files || !req.files.photo) {
         return res.json({ error: true, message: "Please select a cover photo" });
      }

      const { photo } = req.files;
      const db_path = `/booksphoto/${photo.name}`;
      const server_path = `public${db_path}`;

      photo.mv(server_path, async (error) => {
         if (error) {
            return res.json({ error: true, message: error.message });
         }

         try {
            const payload = {
               title: req.body.title,
               author: req.body.author,
               isbn: req.body.isbn,
               publisherName: req.body.publisher,
               publishYear: req.body.year,
               photo: db_path,
               categoryId: req.body.categoryId,
            };

            await book.create(payload);
            return res.json({ error: false, message: 'Added Successfully' });
         } catch (e) {
            return res.json({ error: true, message: e.message });
         }
      });
   } catch (e) {
      return res.json({ error: true, message: e.message });
   }
}

indexController.viewsubcategory = async (req, res) => {
   try {
      var records = await book.findAll(
         {
            include: [
               {
                  model: addcategory,
                  attributes: ['name', 'id']

               }
            ],
            order: [['id', 'DESC']]
         }
      );
      res.json({ message: 'Data Fetched ', records: records });

   } catch (e) {
      res.json({ message: e.message, records: [] });

   }
}

indexController.deletesubcategory = async (req, res) => {
   try {
      const { bookId } = req.params;

      // check book
      const bookRecord = await book.findByPk(bookId);

      if (!bookRecord) {
         return res.json({
            error: true,
            message: "Book not found"
         });
      }

      // check if book is issued
      if (bookRecord.status === 'Issued') {
         return res.json({
            error: true,
            message: "Book cannot be deleted because it is currently issued"
         });
      }

      // delete book
      await book.destroy({
         where: { id: bookId }
      });

      res.json({
         error: false,
         message: "Book deleted successfully"
      });

   } catch (e) {
      res.json({
         error: true,
         message: e.message
      });
   }
}

indexController.renderissuebooksPage = (req, res) => {
   res.render('librarian/issuebooks');
}

indexController.fetchstudent = async (req, res) => {
   try {
      const { branchId } = req.params;
      const records = await UserModal.findAll({ where: { branchId: branchId } });
      res.json({ message: 'Data Fetched ', records: records });
   } catch (e) {
      res.json({ message: e.message, records: [] });

   }
}

indexController.fetchbook = async (req, res) => {
   try {
      const { categoryId } = req.params;
      const records = await book.findAll({ where: { categoryId: categoryId, status: 'Available' } });
      res.json({ message: 'Data Fetched ', records: records });
   } catch (e) {
      res.json({ message: e?.message, records: [] });
   }
}

indexController.submitFinePayment = async (req, res) => {

   const t = await sequelize.transaction();

   try {

      const { issueId, paymentMode, transactionId } = req.body;

      /* -----------------------------
         1. Validate input
      ----------------------------- */

      if (!issueId || !paymentMode) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Issue ID and payment mode are required"
         });
      }

      /* -----------------------------
         2. Find issue record
      ----------------------------- */

      const issueRecord = await issueBook.findByPk(issueId, {
         transaction: t,
         lock: true
      });

      if (!issueRecord) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Issue record not found"
         });
      }

      if (issueRecord.status !== 'Overdue') {
         await t.rollback();
         return res.json({
            error: true,
            message: "Fine payment is not required for this record"
         });
      }

      if (issueRecord.finePaid === true) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Fine already paid"
         });
      }

      /* -----------------------------
         3. Update issue record
      ----------------------------- */

      await issueBook.update(
         {
            finePaid: true,
            paymentMode: paymentMode,
            transactionId: transactionId || null,
            paidAt: new Date(),
            returnedAt: new Date(),
            status: 'Returned'
         },
         {
            where: { id: issueId },
            transaction: t
         }
      );

      /* -----------------------------
         4. Update book status
      ----------------------------- */

      await book.update(
         { status: 'Available' },
         {
            where: { id: issueRecord.bookId },
            transaction: t
         }
      );

      /* -----------------------------
         5. Commit transaction
      ----------------------------- */

      await t.commit();

      return res.json({
         error: false,
         message: "Fine payment completed and book returned successfully"
      });

   } catch (e) {

      await t.rollback();

      return res.json({
         error: true,
         message: e.message || "Internal Server Error"
      });
   }
};

indexController.returnBookHandler = async (req, res) => {

   const t = await sequelize.transaction();

   try {

      const { issueId } = req.body;

      /* -----------------------------
         1. Validate input
      ----------------------------- */

      if (!issueId) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Issue ID is required"
         });
      }

      /* -----------------------------
         2. Find issue record
      ----------------------------- */

      const issueRecord = await issueBook.findByPk(issueId, {
         transaction: t,
         lock: true
      });

      if (!issueRecord) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Issue record not found"
         });
      }

      if (issueRecord.status === 'Returned') {
         await t.rollback();
         return res.json({
            error: true,
            message: "Book already returned"
         });
      }

      /* -----------------------------
         3. Check overdue
      ----------------------------- */

      const today = new Date();
      const dueDate = new Date(issueRecord.dueDate);

      let fineAmount = 0;

      if (today > dueDate) {

         const diffTime = today - dueDate;
         const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

         const finePerDay = 10; // ₹10 per day

         fineAmount = diffDays * finePerDay;

         /* -----------------------------
            4. Update issue record as Overdue
         ----------------------------- */

         await issueBook.update(
            {
               status: 'Overdue',
               fineAmount: fineAmount
            },
            {
               where: { id: issueId },
               transaction: t
            }
         );

         await t.commit();

         return res.json({
            error: false,
            message: "Book is overdue. Collect fine before completing return.",
            fineAmount: fineAmount
         });
      }

      /* -----------------------------
         5. No fine → complete return
      ----------------------------- */

      await issueBook.update(
         {
            returnedAt: today,
            status: 'Returned'
         },
         {
            where: { id: issueId },
            transaction: t
         }
      );

      /* -----------------------------
         6. Update book status
      ----------------------------- */

      await book.update(
         { status: 'Available' },
         {
            where: { id: issueRecord.bookId },
            transaction: t
         }
      );

      /* -----------------------------
         7. Commit transaction
      ----------------------------- */

      await t.commit();

      return res.json({
         error: false,
         message: "Book returned successfully",
         fineAmount: 0
      });

   } catch (e) {

      await t.rollback();

      return res.json({
         error: true,
         message: e.message || "Internal Server Error"
      });
   }
};

indexController.issueBookHandler = async (req, res) => {
   const t = await sequelize.transaction();

   try {

      const { userId, bookId, issuedate, returndate } = req.body;

      /* -----------------------------
         1. Validate input
      ----------------------------- */

      if (!userId || !bookId || !issuedate || !returndate) {
         await t.rollback();
         return res.json({
            error: true,
            message: "All fields are required"
         });
      }

      if (new Date(returndate) <= new Date(issuedate)) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Return date must be after issue date"
         });
      }


      /* -----------------------------
         2. Check student
      ----------------------------- */

      const student = await UserModal.findByPk(userId, { transaction: t });

      if (!student) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Student not found"
         });
      }


      /* -----------------------------
         3. Check student issue limit
      ----------------------------- */

      const issuedCount = await issueBook.count({
         where: {
            userId,
            status: 'Issued'
         },
         transaction: t
      });

      if (issuedCount >= 3) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Student already has maximum allowed issued books"
         });
      }


      /* -----------------------------
         4. Check book with lock
      ----------------------------- */

      const bookRecord = await book.findByPk(bookId, {
         transaction: t,
         lock: true
      });

      if (!bookRecord) {
         await t.rollback();
         return res.json({
            error: true,
            message: "Book not found"
         });
      }

      if (bookRecord.status !== 'Available') {
         await t.rollback();
         return res.json({
            error: true,
            message: "Book is not available"
         });
      }


      /* -----------------------------
         5. Prevent duplicate issue
      ----------------------------- */

      const alreadyIssued = await issueBook.findOne({
         where: {
            userId,
            bookId,
            status: 'Issued'
         },
         transaction: t
      });

      if (alreadyIssued) {
         await t.rollback();
         return res.json({
            error: true,
            message: "This book is already issued to this student"
         });
      }


      /* -----------------------------
         6. Create issue record
      ----------------------------- */

      await issueBook.create({
         userId,
         bookId,
         issuedAt: issuedate,
         dueDate: returndate,
         status: 'Issued'
      }, { transaction: t });


      /* -----------------------------
         7. Update book status
      ----------------------------- */

      await book.update(
         { status: 'Issued' },
         {
            where: { id: bookId },
            transaction: t
         }
      );


      /* -----------------------------
         8. Commit transaction
      ----------------------------- */

      await t.commit();

      return res.json({
         error: false,
         message: "Book Issued Successfully"
      });

   } catch (e) {

      await t.rollback();

      return res.json({
         error: true,
         message: e.message || "Internal Server Error"
      });
   }
};

indexController.issuedata = async (req, res) => {
   try {
      const records = await issueBook.findAll({
         // where: {
         //    status: {
         //       [Sequelize.Op.in]: ['Issued', 'Overdue']
         //    }
         // },
         include: [
            {
               model: book,
               attributes: ['id', 'title']
            },
            {
               model: UserModal,
               attributes: ['id', 'name']
            }
         ],
         order: [['id', 'DESC']]
      });

      res.json({ message: 'Issued Books Fetched', records });
   } catch (e) {
      console.log('----> Error: ', e?.message)
      res.json({ error: true, message: e.message, records: [] });
   }
}

indexController.return = async (req, res) => {
   try {
      var { id } = req.params;
      await issueBook.update(req.body, { where: { id: id } });
      res.json({ error: false, message: 'record updated' });

   } catch (e) {
      res.json({ error: true, message: e.message });

   }

}

indexController.changestatus = async (req, res) => {
   try {
      var { id } = req.params;
      await book.update(req.body, { where: { id: id } });
      res.json({ message: 'record updated' });

   } catch (e) {
      res.json({ message: e.message });

   }

}


indexController.changestatus2 = async (req, res) => {
   try {
      var { bookId } = req.params;
      console.log(bookId)
      await book.update(req.body, { where: { id: bookId } });
      res.json({ message: 'record updated' });

   } catch (e) {
      res.json({ message: e.message });

   }

}




indexController.renderchangepassPage = (req, res) => {
   res.render('librarian/changepass');
}


indexController.updatepass = async (req, res) => {
   try {

      var { email, password, newpassword } = req.body;
      var record = await librarian.findAll({ where: { email: email, password: password } });
      if (record.length > 0) {

         await librarian.update({ password: newpassword }, { where: { email: email } });
         res.json({ error: false, message: 'Password Changed Successfully' });

      }
      else {
         res.json({ error: true, message: 'Password or Email do not match' });
      }
   }
   catch (e) {
      res.json({ error: true, message: e.message });
   }
}

indexController.logoutlib = (req, res) => {
   //console.log("hello ")
   res.clearCookie('librarianToken');
   //  res.json({error: false, message: "login successful"});
   res.redirect('/');
}



module.exports = indexController;